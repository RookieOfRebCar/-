<template>
  <div class="timing">
    <div class="time">
      <span>{{ minute }}</span
      >: <span>{{ second }}</span
      >.
      <span>{{ millisecond }}</span>
    </div>
    <div class="controls">
      <button @click="reseter">{{ resetVal }}</button>
      <div class="dot"><span></span><span></span></div>
      <button @click="timeCount" :class="{ active: !btn }">
        {{ fullClass }}
      </button>
    </div>
    <ul class="history">
      <li v-for="(item, index) in metering" :key="index">
        计次{{ index + 1 }} <span>{{ item }}</span>
      </li>
    </ul>
  </div>
</template>
<script>
export default {
  name: "timing",
  computed: {
    fullClass: {
      get() {
        if (this.btn) {
          return "开始";
        } else {
          return "结束";
        }
      },
    },
    resetVal: {
      get() {
        if (this.btn) {
          return "复位";
        } else {
          return "计次";
        }
      },
    },
  },
  data() {
    return {
      minute: "00",
      second: "00",
      millisecond: "00",
      btn: true,
      mill: "",
      sec: "",
      min: "",
      metering: [],
    };
  },
  methods: {
    timeCount() {
      if (this.btn) {
        this.btn = !this.btn;
        this.mill = setInterval(() => {
          this.millisecond = parseInt(this.millisecond) + 1 + "";
          if (this.millisecond.length < 2) {
            this.millisecond = "0" + this.millisecond;
          }
          if (parseInt(this.millisecond) > 99) {
            this.millisecond = "00";
          }
        }, 10);
        this.sec = setInterval(() => {
          this.second = parseInt(this.second) + 1 + "";
          if (this.second.length < 2) {
            this.second = "0" + (this.second + "");
          }
          if (parseInt(this.second) > 59) {
            this.second = "00";
          }
        }, 1000);
        this.min = setInterval(() => {
          this.minute = parseInt(this.minute) + 1 + "";
          if (this.minute.length < 2) {
            this.minute = "0" + (this.minute + "");
          }
        }, 60000);
      } else {
        this.btn = !this.btn;
        clearInterval(this.mill);
        clearInterval(this.sec);
        clearInterval(this.min);
      }
    },
    reseter() {
      if (this.btn) {
        (this.minute = "00"), (this.second = "00"), (this.millisecond = "00");
        this.metering = [];
      } else {
        let timingNow =
          this.minute + ":" + this.second + "." + this.millisecond;
        this.metering.push(timingNow);
      }
    },
  },
};
</script>
<style scoped lang="css">
.timing {
  width: 100%;
  background-color: #000;
}
.time {
  width: 100%;
  display: flex;
  height: 300px;
  line-height: 300px;
  font-size: 70px;
  color: #fff;
  font-weight: 200;
}
.time span {
  display: block;
  width: 33%;
  font-size: 70px;
  text-align: center;
  font-weight: 200;
}
.controls {
  margin: 0 auto;
  width: 95%;
  display: flex;
  justify-content: space-between;
}
.controls button:first-child {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  border: 5px solid rgba(53, 53, 53, 0.4);
  background-color: rgba(53, 53, 53, 0.6);
  color: aliceblue;
}
.controls button:last-child {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  border: 5px solid rgba(53, 214, 53, 0.1);
  background-color: rgba(0, 214, 0, 0.2);
  color: chartreuse;
}
.controls button.active {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  border: 5px solid rgba(214, 53, 53, 0.1);
  background-color: rgba(214, 0, 0, 0.2);
  color: crimson;
}
.history {
  padding: 30px;
}
.history li {
  widows: 100%;
  color: #fff;
  list-style: none;
  text-align: left;
  font-size: 13px;
  line-height: 30px;
}
.history li span {
  float: right;
}
</style>
