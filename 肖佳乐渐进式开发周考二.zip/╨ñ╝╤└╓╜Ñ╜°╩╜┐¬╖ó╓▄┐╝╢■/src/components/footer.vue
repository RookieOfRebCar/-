<template>
  <div class="footer">
    <dl>
      <dt><img src="../../images/111.jpg" alt="" /></dt>
      <dd>世界时钟</dd>
    </dl>
    <dl>
      <dt><img src="../../images/222_03.jpg" alt="" /></dt>
      <dd>闹钟</dd>
    </dl>
    <dl>
      <dt><img src="../../images/333_03.jpg" alt="" /></dt>
      <dd>秒表</dd>
    </dl>
    <dl>
      <dt><img src="../../images/444_03.jpg" alt="" /></dt>
      <dd>计时器</dd>
    </dl>
  </div>
</template>
<script>
// import icon from "../../public/font_2699225_h2s0x0z86pm/iconfont.css";
export default {
  name: "footer",
};
</script>

<style scoped lang="css">
* {
  margin: 0;
  padding: 0;
  list-style: none;
}
.footer {
  position: fixed;
  bottom: 0;
  width: 100%;
  display: flex;
  color: #fff;
  justify-content: space-around;
}
.footer dl {
  widows: 25%;
  text-align: center;
}
.footer dl dt {
  width: 23px;
  height: 23px;
  text-align: center;
  margin: 0 auto;
}
.footer dl dt img {
  width: 100%;
}
.footer dl dd {
  text-align: center;
}
</style>