<template>
  <div id="app">
    <timing />
    <foot></foot>
  </div>
</template>

<script>
import timing from "./components/timing.vue";
import foot from "./components/footer.vue";

export default {
  name: "App",
  components: {
    timing,
    foot,
  },
};
</script>

<style>
html {
  height: 100%;
}
body {
  height: 100%;
}
#app {
  height: 100%;
  background-color: #000;
}
</style>
